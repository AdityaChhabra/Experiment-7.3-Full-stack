import React, { useEffect, useState, useRef } from 'react';
import { io } from 'socket.io-client';

const SERVER_URL = import.meta.env.VITE_SERVER_URL || 'http://localhost:4000';

export default function App() {
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [username, setUsername] = useState('');
  const [room, setRoom] = useState('general');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [users, setUsers] = useState([]);
  const [typingUsers, setTypingUsers] = useState(new Set());
  const typingTimeout = useRef(null);

  useEffect(() => {
    const s = io(SERVER_URL);
    setSocket(s);
    s.on('connect', () => setConnected(true));
    s.on('disconnect', () => setConnected(false));
    s.on('message', (msg) => setMessages((m) => [...m, msg]));
    s.on('roomData', ({ room, users }) => setUsers(users));
    s.on('typing', ({ user, isTyping }) => {
      setTypingUsers((prev) => {
        const updated = new Set(prev);
        if (isTyping) updated.add(user); else updated.delete(user);
        return updated;
      });
    });
    return () => s.close();
  }, []);

  const joinRoom = () => socket.emit('joinRoom', { username, room });
  const sendMessage = (e) => {
    e.preventDefault();
    if (!message.trim()) return;
    socket.emit('sendMessage', message);
    setMessage('');
    socket.emit('typing', false);
  };
  const handleTyping = (val) => {
    setMessage(val);
    socket.emit('typing', true);
    clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => socket.emit('typing', false), 800);
  };

  return (
    <div className='p-4 max-w-3xl mx-auto'>
      <h1 className='text-2xl font-bold mb-4'>Socket.io Chat</h1>
      {!connected ? <p>Connecting...</p> : !username ? (
        <form onSubmit={(e) => { e.preventDefault(); joinRoom(); }}>
          <input placeholder='Username' value={username} onChange={(e) => setUsername(e.target.value)} className='border p-2 mr-2' />
          <input placeholder='Room' value={room} onChange={(e) => setRoom(e.target.value)} className='border p-2 mr-2' />
          <button type='button' onClick={joinRoom} className='px-3 py-1 bg-blue-600 text-white rounded'>Join</button>
        </form>
      ) : (
        <div>
          <div className='flex gap-4 mb-4'>
            <div className='w-2/3 border p-2 h-96 overflow-auto'>
              {messages.map((m, i) => <div key={i}><strong>{m.user}</strong>: {m.text} <small>{new Date(m.ts).toLocaleTimeString()}</small></div>)}
            </div>
            <div className='w-1/3 border p-2'>
              <h3 className='font-semibold'>Users</h3>
              <ul>{users.map((u) => <li key={u}>{u}</li>)}</ul>
            </div>
          </div>
          {Array.from(typingUsers).length > 0 && <div className='italic mb-2'>{Array.from(typingUsers).join(', ')} typing...</div>}
          <form onSubmit={sendMessage} className='flex gap-2'>
            <input value={message} onChange={(e) => handleTyping(e.target.value)} className='flex-1 border p-2' placeholder='Type a message' />
            <button type='submit' className='px-3 py-1 bg-green-600 text-white rounded'>Send</button>
          </form>
        </div>
      )}
    </div>
  );
}
