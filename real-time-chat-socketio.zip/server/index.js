import express from 'express';
import http from 'http';
import { Server } from 'socket.io';

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

const PORT = process.env.PORT || 4000;
const rooms = new Map();

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  socket.on('joinRoom', ({ username, room }) => {
    socket.data.username = username;
    socket.data.room = room;
    socket.join(room);
    if (!rooms.has(room)) rooms.set(room, new Set());
    rooms.get(room).add(username);

    socket.emit('message', { user: 'system', text: `Welcome ${username} to ${room}`, ts: Date.now() });
    socket.to(room).emit('message', { user: 'system', text: `${username} joined the room`, ts: Date.now() });
    io.in(room).emit('roomData', { room, users: Array.from(rooms.get(room)) });
  });

  socket.on('sendMessage', (text) => {
    const username = socket.data.username || 'Anonymous';
    const room = socket.data.room;
    if (!room) return;
    io.in(room).emit('message', { user: username, text, ts: Date.now() });
  });

  socket.on('typing', (isTyping) => {
    const username = socket.data.username;
    const room = socket.data.room;
    if (room) socket.to(room).emit('typing', { user: username, isTyping });
  });

  socket.on('disconnect', () => {
    const username = socket.data.username;
    const room = socket.data.room;
    if (room && rooms.has(room)) {
      rooms.get(room).delete(username);
      socket.to(room).emit('message', { user: 'system', text: `${username} left the room`, ts: Date.now() });
      io.in(room).emit('roomData', { room, users: Array.from(rooms.get(room)) });
      if (rooms.get(room).size === 0) rooms.delete(room);
    }
    console.log('Client disconnected:', socket.id);
  });
});

app.get('/', (req, res) => res.send('Socket.io Chat Server Running'));
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
